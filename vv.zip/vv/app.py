from flask import Flask, render_template, request, redirect, url_for
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Dummy list of model names
MODEL_NAMES = ['Model_A', 'Model_B', 'Model_C']

# Dummy function for running inference
def run_model(model_name, audio_path):
    # Replace this with your actual logic
    return f"Predicted label by {model_name} for {os.path.basename(audio_path)}"

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None

    if request.method == 'POST':
        selected_model = request.form['model']
        audio_file = request.files['audio']

        if audio_file and selected_model:
            filename = secure_filename(audio_file.filename)
            audio_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            audio_file.save(audio_path)

            prediction = run_model(selected_model, audio_path)

    return render_template('index.html', model_names=MODEL_NAMES, prediction=prediction)

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True)
